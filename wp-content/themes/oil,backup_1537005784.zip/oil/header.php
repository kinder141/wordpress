<!DOCTYPE html>
<html lang="ru">

<head>

    <meta charset="utf-8">
    <!-- 	<base href="/"> -->

    <title><?php bloginfo('name'); ?></title>
    <meta name="description" content="">

    <meta name="format-detection" content="telephone=no">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <!-- Template Basic Images Start -->
    <meta property="og:image" content="path/to/image.jpg">
    <link rel="icon" href="<?php bloginfo('template_url')?>/img/favicon/title.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php bloginfo('template_url')?>/img/favicon/title.png">
    <!-- Template Basic Images End -->

    <!-- Custom Browsers Color Start -->
    <meta name="theme-color" content="#000">
    <!-- Custom Browsers Color End -->
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>

    <link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
    <?php wp_head(); ?>

</head>

<body>
<header>

    <div class="mobile_nav hidden">
        <nav>
            <ul>
                <li><a href="" title="">Главная</a></li>
                <li><a href="" title="">Продукция</a></li>
                <li><a href="" title="">Технологии</a></li>
                <li><a href="" title="">Контакты</a></li>
                <li><a href="" title="">Статьи</a></li>
                <li><a href="" title="">Оплата и доставка</a></li>
                <li><a href="" title="">О Нас</a></li>
                <li><img src="<?php bloginfo('template_url')?>/img/mobile_cart.png" alt="Корзина"></li>
            </ul>
        </nav>
    </div>
    <div class="top_line">
        <div class="container">
            <div class="icons">
                <a href=""><i class="fab fa-facebook-f"></i></a>
                <a href=""><i class="fab fa-youtube"></i></a>
            </div>
            <div class="number">
                <p>+38 050 111 11 11</p>
                <p>+38 050 111 11 11</p>
            </div>
        </div>
    </div>
    <div class="menu">
        <div class="container">
            <div class="logo"><a href="<?php echo home_url(); ?> "><img src="<?php bloginfo('template_url')?>/img/Logo.png" alt="Логотип"></a></div>
            <nav>
                <ul>
                    <li><a href="" title="">Главная</a></li>
                    <li><a href="" title="">Продукция</a></li>
                    <li><a href="" title="">Технологии</a></li>
                    <li><a href="" title="">Контакты</a></li>
                    <li><a href="" title="">Статьи</a></li>
                    <li><a href="" title="">Оплата и доставка</a></li>
                    <li><a href="" title="">О Нас</a></li>
                    <li><img src="<?php bloginfo('template_url')?>/img/Shoping_cart.png" alt="Корзина"></li>
                </ul>
            </nav>
        </div>
        <button class="hamburger hamburger--stand" type="button">
				  <span class="hamburger-box">
				    <span class="hamburger-inner"></span>
				  </span>
        </button>
    </div>

    <div class="header_slider">
        <div class="slide" style="background-image: url(<?php bloginfo('template_url')?>/img/header_slide1.png);">
            <div class="kendall_slide_logo">
                <img class="kendall_text_logo" src="<?php bloginfo('template_url')?>/img/Kendall.png" alt=""><br>
                <img class="img_logo" src="<?php bloginfo('template_url')?>/img/kendall_img.png" alt="">
            </div>
        </div>
        <div class="slide" style="background-image: url(<?php bloginfo('template_url')?>/img/header_slide1.png);">
            <div class="kendall_slide_logo">
                <img class="kendall_text_logo" src="<?php bloginfo('template_url')?>/img/Kendall.png" alt=""><br>
                <img class="img_logo" src="<?php bloginfo('template_url')?>/img/kendall_img.png" alt="">
            </div>
        </div>
        <div class="slide" style="background-image: url(<?php bloginfo('template_url')?>/img/header_slide1.png);">
            <div class="kendall_slide_logo">
                <img class="kendall_text_logo" src="<?php bloginfo('template_url')?>/img/Kendall.png" alt=""><br>
                <img class="img_logo" src="<?php bloginfo('template_url')?>/img/kendall_img.png" alt="">
            </div>
        </div>
    </div>

</header>