<?php get_header(); ?>

	<section>
		
		<div class="revolutionary_technology">
			<div class="container">
				<div class="tech_block">
					<img src="<?php bloginfo('template_url')?>/img/Liquid_titanium.png" alt="Liquid_titanium">
					<p class="revolutionary">революционная<br>технология</p>
				</div>
				<div class="tech_block">
					<div class="about_kendall">
						<p>Моторное масло Kendall® с жидкой защитной добавкой Titanium® образует щит для двигателей, связывая самые горячие детали, чтобы уменьшить трение.</p>
						<a href="">Подробнее</a>
					</div>
					<img class="molecule" src="<?php bloginfo('template_url')?>/img/molecule.png" alt="">
				</div>
			</div>
		</div>

	</section>

	<section>
		
		<div class="production">
			<div class="production_kendall">
				<h2>Продукция от компании <img src="<?php bloginfo('template_url')?>/img/Kendall.png" alt="Kendall"></h2>
			</div>
			<div class="production_photo">
				<img class="product_BG" src="<?php bloginfo('template_url')?>/img/product_BG.png" alt="">
				<div class="container">
					<div class="product_line_first">
						<div  class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_1.png" alt="">
							<p style="background-image: url(img/product_BG.png);">Моторное масло для бензиновых двигателей</p>
						</div>
						<div class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_2.png" alt="">
							<p style="background-image: url(<?php bloginfo('template_url')?>/img/product_BG.png);">Жидкость для трансмиссий</p>
						</div>
						<div class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_3.png" alt="">
							<p style="background-image: url(img/product_BG.png);">Моторное масло для дизельных двигателей</p>
						</div>
					</div>
				</div>
				<img class="product_BG_2" src="<?php bloginfo('template_url')?>/img/product_BG.png" alt="">
				<div class="container">
					<div class="product_line_second">
						<div class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_4.png" alt="">
							<p style="background-image: url(img/product_BG.png);">Трансмиссионное масло</p>
						</div>
						<div class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_5.png" alt="">
							<p style="background-image: url(img/product_BG.png);">Смазки</p>
						</div>
						<div class="product">
							<img src="<?php bloginfo('template_url')?>/img/kend_prod_6.png" alt="">
							<p style="background-image: url(img/product_BG.png);">Гидравлическое масло</p>
						</div>
					</div>
				</div>
				</div>
			</div>
		</div>

	</section>

	<section>
		
		<div class="lubricants">
			<div class="container">
				<div class="family"><img src="<?php bloginfo('template_url')?>/img/family.png" alt=""></div>
				<div class="leader_in_USA">
					<h3>Смазочные материалы от лидера на рынке США</h3>
					<p><span>Моторное масло Kendall®</span> с жидкой защитной добавкой Titanium® образует щит для двигателей, связывая самые горячие детали, чтобы уменьшить трение. В каждом стандартном отраслевом тесте двигатели, использующие Kendall® с Liquid Titanium®, оказались более долговечными, чем те, у кого нет. Когда вы помещаете Kendall в свой двигатель, вы сражаетесь с измельчением и носите на молекулярном уровне с дополнительным слоем титана. Изучите конкретные преимущества в видео ниже. <br><br>
						 <span>Моторное масло Kendall®</span> <br>
						 <span>Моторное масло Kendall®</span> с жидкой защитной добавкой Titanium® образует щит для двигателей, связывая самые горячие детали, чтобы уменьшить трение. В каждом стандартном отраслевом тесте двигатели, использующие Kendall® с Liquid Titanium®, оказались более долговечными, чем те, у кого нет. Когда вы помещаете Kendall в свой двигатель, вы сражаетесь с измельчением и носите на молекулярном уровне с дополнительным слоем титана. Изучите конкретные преимущества в видео ниже.</p>
				</div>
			</div>
		</div>

	</section>

	<?php get_footer();?>
